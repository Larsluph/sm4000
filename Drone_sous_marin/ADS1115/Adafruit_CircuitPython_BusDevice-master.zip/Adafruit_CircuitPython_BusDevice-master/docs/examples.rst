Simple test
------------

Ensure your device works with this simple test.

.. literalinclude:: ../examples/read_register_i2c.py
    :caption: examples/read_register_i2c.py
    :linenos:

.. literalinclude:: ../examples/read_register_spi.py
    :caption: examples/read_register_spi.py
    :linenos: